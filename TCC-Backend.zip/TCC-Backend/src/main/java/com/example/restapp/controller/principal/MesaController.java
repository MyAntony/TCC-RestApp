package com.example.restapp.controller.principal;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.example.restapp.dto.MesaDTO.*;
import com.example.restapp.service.MesaService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("principal/mesas")
@CrossOrigin(origins = "*")
public class MesaController
{
    @Autowired
    private MesaService mesaService;

    // Create
    @PostMapping
    public ResponseEntity<Map<String, Object>> criarMesa(@RequestBody MesaRequestDTO mesaRequestDTO)
    {
        mesaService.salvar(mesaRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of("mensagem", "Pedido cadastrado com sucesso!"));
    }

    // @GetMapping
    // public ResponseEntity<List<MesaResponseDTO>> listarMesas()
    // {
    //     List<MesaResponseDTO> mesas = mesaService.listarTodas();
    //     return new ResponseEntity<>(mesas, HttpStatus.OK);
    // }


    // Read
    @GetMapping("/{id}")
    public ResponseEntity<MesaResponseDTO> obterMesaPorId(@PathVariable Long id)
    {
        MesaResponseDTO mesaResponseDTO = mesaService.obterPorId(id);
        return new ResponseEntity<>(mesaResponseDTO, HttpStatus.OK);
    }

    // Update
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> atualizarMesa(@PathVariable Long id, @Valid @RequestBody MesaRequestDTO mesaRequestDTO)
    {
        mesaService.atualizar(id, mesaRequestDTO);
        return ResponseEntity.status(HttpStatus.OK).body(Map.of("mensagem", "Mesa atualizado com sucesso"));
    }

    // Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarMesa(@PathVariable Long id)
    {
        mesaService.deletar(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}