package com.example.restapp.model.principal;

import java.time.*;
import java.util.*;
import org.springframework.data.annotation.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.example.restapp.model.Usuario;
import com.example.restapp.model.enums.StatusMesa;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import jakarta.persistence.Id;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity // Indica que a classe é uma entidade JPA
@EntityListeners(AuditingEntityListener.class) // Habilita o listener de auditoria para o @CreatedBy e @CreatedDate funcionarem
@Getter // Gera os getters
@Setter // Gera os setters
// @AllArgsConstructor // Gera o construtor com todos os argumentos
@NoArgsConstructor // Gera o construtor sem argumentos
public class Mesa
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonManagedReference
    @OneToMany(mappedBy = "mesa", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Pedido> pedidos= new ArrayList<>();

    @JoinColumn(name = "atendente_abertura_id", nullable = false, updatable = false)
    @ManyToOne(fetch = FetchType.LAZY)
    @CreatedBy
    private Usuario atendenteAbertura;

    @CreatedDate
    private LocalDateTime horarioAbertura;

    // @ManyToOne(fetch = FetchType.LAZY)
    // @JoinColumn(name = "atendente_responsavel_id")
    // private Usuario atendenteResponsavel;

    @NotNull(message = "O número da mesa é obrigatório.")
    private Integer numeroMesa;

    private Integer quantidadePessoas;

    // @JsonBackReference
    // @ManyToOne(fetch = FetchType.LAZY)
    // @JoinColumn(name = "cliente_id")
    // private Cliente cliente;
    
    @Enumerated(EnumType.STRING)
    private StatusMesa status;

    private LocalDateTime horarioFechamento;

    private Double valorTotalMesa;

    private Double valorTotalMesaServico;

    // @PreUpdate
    // public void aoAtualizar()
    // {
    //     if (this.status == StatusMesa.FECHAMENTO)
    //     {
    //         this.horarioFechamento = LocalDateTime.now();
    //     }
    // }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (!(o instanceof Mesa)) return false;
        Mesa other = (Mesa) o;
        // Compara apenas pelo ID.
        return id != null && id.equals(other.getId());
    }

    @Override
    public int hashCode()
    {
        // Usa o ID para o hashCode.
        return getClass().hashCode();
    }
    
}
