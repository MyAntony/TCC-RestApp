package com.example.restapp.model.principal;

import java.util.*;
import com.example.restapp.model.Endereco;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Getter // Gera os getters
@Setter // Gera os setters
@AllArgsConstructor // Gera o construtor com todos os argumentos
@NoArgsConstructor // Gera o construtor sem argumentos
@Table(name = "cliente", uniqueConstraints = @UniqueConstraint(columnNames = "cpf"))
public class Cliente
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "O nome é obrigatório.")
    private String nome;

    private String cpf;

    private String telefone;

    private String email;

    // @JsonManagedReference
    // @OneToMany(mappedBy = "cliente")
    // private List<Mesa> mesas= new ArrayList<>();

    @Embedded // Indica que o endereço é um campo embutido
    private Endereco endereco;
}
